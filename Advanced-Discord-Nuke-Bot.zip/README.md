# Advanced-Discord-Nuke-Bot
This is the best discord nuking bot ever made!

# Commands:

## Kall
Kicks every member in a server
## Ball
Bans every member in a server
## Rall
Renames every member in a server
## Mall
Messages every member in a server
## Destroy
Deleted channels, remakes new ones, deletes roles, bans members, and wipes emojis. In that order
## Ping
Gives ping to client (expressed in MS)
## Info
Gives information of a user

# Discord Server:
## https://discord.gg/kE9vk9Zeuf
